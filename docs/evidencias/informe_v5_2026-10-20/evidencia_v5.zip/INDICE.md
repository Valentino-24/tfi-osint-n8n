# Paquete de evidencia - informe V5

Generado para la reentrega V5 del TFI OSINT/n8n. Responde a los hallazgos
H-07 (acceso verificable a la evidencia) y H-15 (código de los nodos y SQL de
persistencia/consultas), a la observación m-29 (transcripción del upsert), y a
la corrección obligatoria N-07 de la devolución de la V4 (origen de las cifras
de las versiones anteriores).

Corte del corpus: 2026-10-17 (último día recolectado); instante de corte
2026-10-18 00:00 hora local; consultas ejecutadas el 2026-10-19.

## Contenido

### Código y esquema

- anexo_b/hmac_anonymize.js          - código del nodo HMAC Anonymize
- anexo_b/classify_dictionary.js     - código del nodo Classify Dictionary
- anexo_b/extract_entities.js        - código del nodo Extract Entities
- anexo_b/anomaly_engine.js          - código del nodo Anomaly Engine
- anexo_b/upsert_posts.sql           - SQL del nodo Upsert Posts
- anexo_b/query_daily_counts.sql     - SQL del nodo Query Daily Counts
- anexo_b/registrar_anomalias.sql    - SQL del nodo Registrar Anomalias y Alertas
- anexo_b/consultas_q1_q15.sql       - consultas Q1..Q15 del Capítulo 5
- anexo_b/consultas_q1_q15_validacion.md - validación de Q1..Q15 contra la salida archivada
- anexos/B_workflow.json             - workflow desplegado (17 nodos)
- anexos/A_DDL.sql                   - DDL del esquema físico

### Salidas y recálculos

- consultas_corpus_b5.txt            - salida literal de Q1..Q15 (19/10/2026)
- evidencias/recalculo_cifras_v5.sql - recálculo independiente de las cifras clave
- evidencias/recalculo_cifras_v5_resultados.txt - salida literal del recálculo
- evidencias/auditoria_diccionario.md
- evidencias/latencia_descomposicion.md
- evidencias/motor_anomalias_recalculo.md
- evidencias/correspondencia_casos_v5.csv

### Validación del clasificador (352 casos, tres anotadores)

- evidencia-muestreo/sorteo_v5.py                 - sorteo reproducible (semilla 20261020)
- evidencia-muestreo/diseno-muestreo.md           - diseño del muestreo estratificado
- evidencia-muestreo/guia_etiquetado_v5.md        - guía de anotación
- evidencia-muestreo/README_ANOTADORES.txt        - instrucciones del paquete
- evidencia-muestreo/muestra_v5_correspondencia.csv - código interno, id, fecha y predicción
- evidencia-muestreo/muestra_v5_anot1.csv / .xlsx - hoja ciega del anotador 1
- evidencia-muestreo/muestra_v5_anot2.csv / .xlsx - hoja ciega del anotador 2
- evidencia-muestreo/muestra_v5_etiquetado.csv / .xlsx - etiquetado consolidado
- evidencia-muestreo/adjudicacion_v5.xlsx         - adjudicación por consenso
- evidencia-muestreo/evaluar_v5.py                - cálculo de acuerdo (kappa)
- evidencia-muestreo/analizar_v5.py               - cálculo de métricas e intervalos
- evidencia-muestreo/resultados_v5.json / .md     - salida literal (fuente de la Tabla 5.8)
- evidencia-muestreo/generar_evidencia_muestreo.py - generación del paquete
- evidencia-muestreo/paquete_anotadores_v5.zip    - paquete entregado a los anotadores

### Declaración

- Declaracion_trazabilidad_versiones.md - declaración jurada de trazabilidad entre
  versiones (Anexo E del informe), con el inventario de resultados de V2/V3, su
  origen declarado y el ciclo de vida de los datos.

Todas las consultas son de solo lectura. El paquete no contiene credenciales,
tokens ni la clave HMAC.
